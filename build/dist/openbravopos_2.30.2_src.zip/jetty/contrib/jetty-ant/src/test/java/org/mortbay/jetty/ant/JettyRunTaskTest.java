package org.mortbay.jetty.ant;

import junit.framework.TestCase;

public class JettyRunTaskTest extends TestCase
{
    public void testInit()
    {

    }
}
